from setuptools import setup

setup(
    name="paquetesCalculos",
    version="1.0",
    description="Calculos matematicos",
    author="Fabio",
    author_email="femtjah@gmail.com",
    packages=["Calculos","Calculos.basicos"]
)
