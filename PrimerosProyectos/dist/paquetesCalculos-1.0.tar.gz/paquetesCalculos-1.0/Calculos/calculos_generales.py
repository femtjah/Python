def sumar(op1,op2):
    print("El resultado de la suma es: ", op1+op2)

def resta(op1,op2):
    print("El resultado de la resta es: ", op1-op2)

def mul(op1,op2):
    print("El resultado de la Multiplicacion es: ", op1*op2)   

def dividir(dividendo,divisor):
    print("El resultado de la devision es: ", dividendo/divisor) 

def potencia(base,exponente):
    print("El resultado de la potencia es: ", base**exponente) 

def redondear(numero):
    print("El numero redondeado es: ", round(numero)) 